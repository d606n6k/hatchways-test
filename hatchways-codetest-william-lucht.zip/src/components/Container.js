import React from "react";
import SectionOne from "./SectionOne";


function Main() {
    return (
      <main>
          <SectionOne />
      </main>
    );
  }

  export default Main;